// 1. Write a program that determines the type of triangle based on the lengths of its sides (`side1`, `side2`, and `side3`). The types of triangles are equilateral, isosceles, and scalene.

var side1 = 5;
var side2 = 5;
var side3 = 8;
var triangleType;
if(side1 == side2 && side1 == side3 && side2 == side3) {
  triangleType = 'equilateral';
} else if(side1 == side2 || side1 == side3 || side2 == side3) {
  triangleType = 'isosceles';
} else {
  triangleType = 'scalene';
}
console.log(triangleType);


// 2. Write a JavaScript program that counts the number of occurrences of a specific element in an array using a for...of loop.

function countOccurrences(arr, target) {
  var count = 0;
  for(var i = 0; i < arr.length; i++) {
    if(arr[i] == target) {
      count++;
    }
  }
  return count;
}
var numbers = [1, 2, 3, 2, 4, 2, 5];
console.log(countOccurrences(numbers, 2)); 


// 3. Write a function that takes an array of product prices and returns the total price. 
//You can assume that the array contains only numbers.

function calculateTotalPrice(prices) {
  var totalPrices = 0;
  for(var i = 0; i < prices.length; i++) {
    totalPrices += prices[i];
  }
  return totalPrices;
}

// Example usage:
var productPrices = [10, 20, 30, 40];
console.log(calculateTotalPrice(productPrices)); 


// 4. Write a function that takes an array of product prices and a discount percentage. 
//Apply the discount to each product price and return the updated prices as an array.

function applyDiscount(prices, discount) {
  discountPrices = [];
  for(var i = 0; i < prices.length; i++) {
    discountPrices[i] = (prices[i] * (100-discount)/100);
  }
  return discountPrices;
}

// Example usage:
var productPrices = [10, 20, 30, 40];
var discountPercentage = 20;
console.log(applyDiscount(productPrices, discountPercentage));


// 5. Write a function that takes an array of product quantities and 
//returns an array of indices for products that are out of stock (quantity is 0).

function getOutOfStockProducts(quantities) {
  var productsIndexOutOfStock = [];
  for(var i = 0; i < quantities.length; i++) {
    if(quantities[i] == 0) {
      productsIndexOutOfStock.push(i)
    }
  }
  return productsIndexOutOfStock;
}

// Example usage:
var productQuantities = [2, 0, 4, 0, 3];
console.log(getOutOfStockProducts(productQuantities));


// 6. Print the multiplication table of 7
// It should be in the format: 
// 7 * 1 = 7

for(var multipliedBy = 0; multipliedBy <= 12; multipliedBy++) {
  equals = 7 * multipliedBy;
  console.log('7 * ' + multipliedBy + ' = ' + equals);
}


// 7. Create a function to calculate factorial of a number.
// Assume that the input is an integer
// Example: Factorial of 5 = 120

function calculateFactorial(n) {
  var factorial;
  if(n < 0) {
    factorial = 'Input must be a positive integer';
  } else if(n == 0) {
    factorial = 1
  } else {
    factorial = n;
    for(n; n > 1; n--) {
      factorial *= n-1; 
    }
  }
  return factorial
}

// Example Usage
console.log(calculateFactorial(0));     // Should print 1
console.log(calculateFactorial(5));     // Should print 120
console.log(calculateFactorial(10));    // Should print 3628800
console.log(calculateFactorial(-1));    // Should print "Input must be a positive integer"


// 8. Create a function to generate fibonacci series. 
// Fibonacci Series is a sequence of numbers in which each number is the sum of the two preceding ones. It starts with 0 and 1.
// The number of terms of the series should be passed as argument to the function.
// Example: Fibonacci series of 5 terms => 0 1 1 2 3 
// Assume that the inputs are positive integers

function generateFibonacciSeries(numTerms) {
  var fibonacciSeries;
  if(numTerms <= 0) {
    fibonacciSeries = 'Input must be a positive integer';
  } else if(numTerms == 1) {
    fibonacciSeries = [0];
  } else if (numTerms == 2) {
    fibonacciSeries = [0, 1];
  } else {
    fibonacciSeries = [0, 1];
    for(var i = 2; i < numTerms; i++) {
      fibonacciSeries[i] = fibonacciSeries[i-1] + fibonacciSeries[i-2];
    }
  }
  return fibonacciSeries;
}

// Example Usage
console.log(generateFibonacciSeries(0));   // Should print "Input must be a positive integer"
console.log(generateFibonacciSeries(1));   // Should print [0]
console.log(generateFibonacciSeries(5));   // Should print [0, 1, 1, 2, 3]
console.log(generateFibonacciSeries(10));  // Should print [0, 1, 1, 2, 3, 5, 8, 13, 21, 34]


// 9. Create a function to print a star-pattern triangle 
// The function should take number of rows as an argument
// Assume that the argument passed is a positive integer
// The pattern should appear as follows for input = 5
// *
// * *
// * * *
// * * * *
// * * * * *

function printTriangle(rows) {
  for(var rowNumber = 1; rowNumber <= rows; rowNumber++) {
    console.log('* '.repeat(rowNumber))
  }
}

// Example Usage
printTriangle(5);
printTriangle(7);


// 10. Create a function to reverse a string. 
// Pass a string as an argument.
// Assume that the argument is always a string.

function reverseString(inputString) {
  var splitString = inputString.split(''); // Create new array from inputString
  var reverseArray = splitString.reverse(); // Reverse the order of the new created array
  var outputString = reverseArray.join(''); // Join all elements of the array into output string
  return outputString; // Display reversed inputString
}

// Example Usage
console.log(reverseString("Hello, World!"));  // Should print "!dlroW ,olleH"
console.log(reverseString("12345"));          // Should print "54321"
console.log(reverseString(""));               // Should print ""
       
