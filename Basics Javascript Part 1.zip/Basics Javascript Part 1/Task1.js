//1. Create a variable `isHappy` and assign it a boolean value based on the value of the given String variable `action`, whether it is `Smile` or not.

var action = "Smile";
var isHappy = action == "Smile";
console.log(isHappy);


// 2. Create a variable `favoriteSubjects` and assign it an array of strings representing your favorite subjects.

var favoriteSubjects = ['Mathematics', 'Coding', 'Electrical Engineering', 'Data Science', 'History']
console.log(favoriteSubjects);


// 3. Write a program to compare two numbers, `num1` and `num2`, and check if `num1` is greater than or equal to `num2`.

var num1 = 10;
var num2 = 5;
var compareNumbers = num1 >= num2;
console.log(compareNumbers);


// 4. Write a program to calculate the square of a given number, `num`.

var num = 4;
var square = num ** 2;
console.log(square);


// 5. Write a program to check if a given number, `num`, is even or odd.

var num = 7;
var evenNumber = num % 2 == 0;
console.log(evenNumber);


// 6. Write a program to check if a given year, `year`, is a leap year and divisible by 400 or divisible by 4 but not divisible by 100.

var year = 2024;
var leapYear = year % 4 == 0 && year % 100 != 0 || year % 400 == 0;
console.log(leapYear);


// 7. Write a program that checks if a given character, `char`, is a vowel or a consonant.

var char = "a";
var vowels = ['a', 'e', 'i', 'o', 'u'];  // Array of all the vowels  
if(vowels.indexOf(char.toLowerCase()) >= 0) {  // Convert 'char' to lower case and check if 'char' is in the array 'vowels'
    console.log('vowel');  // If 'char' is in the array 'vowels', print vowel to console
} else {
    console.log('consonant'); // If index is -1 ('char' is NOT in the array 'vowels'), print consonant to console
}


// 8. Write a program that determines the largest among three numbers, `num1`, `num2`, and `num3`.

var num1 = 10;
var num2 = 5;
var num3 = 8;
var largest;
largest = num1; //set 'largest' to 'num1' to start
if(largest < num2) {
    largest = num2; // set 'largest' to 'num2' if greater than 'largest'
}
if (largest < num3) {
    largest = num3; // set 'largest' to 'num3' if greater than 'largest'
}
console.log(largest);


// 9. Write a program that determines the sign of a given number, `num` (positive, negative, or zero), using the ternary operator.

var num = -5, sign;
num < 0 ? sign = 'negative' : num > 0 ? sign = 'positive' : sign = 'zero'; // Check if 'num' is positive, negative, or zero
console.log(sign);


// 10. Write a program that determines the grade based on a given percentage, `percentage`. Use the following grading scale: A (90-100), B (80-89), C (70-79), D (60-69), F (0-59).

var percentage = 85, grade;

if(percentage >= 90) {
    grade = 'A';
} else if(percentage >= 80) {
    grade = 'B';
} else if(percentage >= 70) {
    grade = 'C';
} else if(percentage >= 60) {
    grade = 'D';
} else{
    grade = 'F';
}
console.log(grade);